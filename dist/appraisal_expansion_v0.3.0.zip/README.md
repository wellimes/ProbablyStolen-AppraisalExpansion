# 深空鉴定拓展 Appraisal Expansion — 使用说明

> 《Probably Stolen》(深空当铺：可能是偷的) Steam 创意工坊 Mod · v0.2.0
> 参考架构：公司增强 CorpPresence

## 一、Mod 功能

### 1. 夜晚拾荒掉落三种鉴定物品（赝品/次品为主，正品稀有）
- 掉落表 `scav_appraisal_table` 挂进游戏拾荒掉落组 `dumpingGroundTG`（组内权重 30/1030）
- 每次拾荒主掉落概率：**机械手 1.29% · 肋排 0.97% · 等离子 0.65%**（合计约 2.9%；详见 loot_report.md）
- 每种物品按"越完好越稀有"掷品质，赝品/次品占多数：
  - 机械手：顶级 1% · 高级 3% · 中档 5% · 基础 11% · 次品(随机) 40% · 次品(磨损/损坏) 40%
  - 肋排：双份肉 2% · 豪华 8% · 普通 20% · 次品(开封) 20% · 赝品(假货) 50%
  - 等离子：实验室 3% · 中华 8% · 共和国 8% · LL 21% · 次品/赝品(无标识NONE等) 60%
- 赝品/次品都走原版 `*Helper.Init*` 打标签，鉴定时 `GetCorrectValue` 自动按原版规则估价。

### 2. 六位供货商（各自每周固定一天上门 + 可电话召唤）

| 供货商 | 上门日 | 电话 | 卖什么 |
|---|---|---|---|
| 三明治供货商 | 周一 | 55521 | 肋排三明治 |
| 机械手供货商 | 周二 | 55522 | 机械手 |
| LL等离子供货商 | 周三 | 55523 | LL 封条等离子 |
| 中华等离子供货商 | 周四 | 55524 | 中华封条等离子 |
| 共和国等离子供货商 | 周五 | 55525 | 共和国封条等离子 |
| 点火实验室等离子供货商 | 周六 | 55526 | 点火实验室封条等离子 |

- 每人独立额度：买谁的货涨谁的额度，≥300 解锁高级档。
- 拨打电话（号码见上）→「好的，明天过来」→ 该商人**下一游戏日**上门。

### 3. 杰克逊博士夜晚店铺补货
- 在原版杰克逊博士夜晚店铺（dr_jackson）里，通过 `OnAfterhourArriveLate` 自动补货：
  - 始终：2 份「无标识等离子燃料」（`PLASMA_SEAL=NONE`，杰克逊博士自制，无封条溢价）
  - 第 20 天起：1 份「等离子原料（自制）」——**已打高级违禁品标签**（CONTRABAND_LEVEL_HIGH = 3）
  - 第 40 天起：1 台制作机器（暂用原版 `current_converter` 占位）

### 4. 下层居民 + 上层收藏家（买家）
- 混入每日随机顾客池，购买机械手/肋排/等离子三种物品。

## 二、文件结构

```
appraisal_expansion/
├── manifest.xml                 # Mod 清单（v0.2.0）
├── AppraisalExpansion.dll       # 已编译的 Mod（实现 IMod）
└── LootTables/
    └── scav_appraisal.json      # 拾荒掉落表 + 补丁
```

## 三、安装与测试

1. 双击 `D:\Appdata\Deepseek\深空鉴定拓展\install_mod.bat`（或手动复制整个 mod 文件夹到游戏 `Mods\appraisal_expansion\`）。
2. 启动 Steam → 启动游戏 → 主菜单「模组」→ 开启「深空鉴定拓展」。
3. 读档实测：拾荒掉落、6 位商人按周上门、电话本 55521–55526、拨号召唤、杰克逊店铺补货、违禁品标签。

## 四、上传创意工坊（SteamCMD）

游戏 AppID = **4348910**。用 SteamCMD 上传（`upload.vdf` 内容见下）：

```
"workshopitem"
{
    "appid"            "4348910"
    "publishedfileid"  "0"
    "contentfolder"    "D:\\Appdata\\Deepseek\\深空鉴定拓展\\appraisal_expansion"
    "previewfile"      "D:\\...\\preview.png"
    "visibility"       "0"
    "title"            "深空鉴定拓展 Appraisal Expansion"
    "description"      "拾荒可捡到机械手/肋排/等离子燃料（赝品次品为主）；6位供货商各自每周固定上门+电话召唤；杰克逊博士夜晚店铺与高级违禁品原料；新增下层/上层居民。"
    "changenote"       "v0.2.0"
}
```

上传命令：`steamcmd +login 你的账号 +workshop_build_item D:\...\upload.vdf +quit`

## 五、修改后重新编译（无需 .NET SDK）

源码：`D:\Appdata\Deepseek\深空鉴定拓展\mod_build\AppraisalExpansion.cs`（C#5 语法）

```bash
M="D:/Download/STEAM/steamapps/common/Probably Stolen/Probably Stolen_Data/Managed"
CSC="/c/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe"
"$CSC" -nologo -target:library -langversion:5 -codepage:65001 \
  -out:AppraisalExpansion.dll \
  -r:"$M/netstandard.dll" -r:"$M/System.Runtime.dll" \
  -r:"$M/Assembly-CSharp.dll" -r:"$M/Assembly-CSharp-firstpass.dll" \
  -r:"$M/UnityEngine.CoreModule.dll" \
  AppraisalExpansion.cs
```

> 注意：`DirectoryMaster.Item("x", true)` 和 `ModifyTag("x", ..., false)` 必须带第二个/第三个参数以消歧（旧 csc 会误匹配泛型重载）。

## 六、已知限制 / 下一步

- 「制作机器」暂用 `current_converter` 占位；**制作流程**（机器+原料→产出）尚未实现，需定：机器摆店投入原料产出，还是直接购买。
- 6 位商人目前复用原版"商人"立绘，显示名走 `locID=displayName` 回退（无多语言）。
- 无标识等离子"是杰克逊制造"的设定目前只在物品层体现，游戏内剧情文本未写。
- 拾荒掉率可调：改 `LootTables/scav_appraisal.json` 里组内权重（当前 30）或表内 40/30/20 即可。
